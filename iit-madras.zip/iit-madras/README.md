1)Download Files
2)Go to root folder 
 Execute Command : php artisan serve

 3)check below path:
 http://localhost:8000/home
 http://localhost:8000/projects

 Completed in mobile and Web view