<section id="feature" >
        <div class="container">
           <div class="center wow fadeInDown">
                <h2>Welcome to Joy of Giving,
the fundraising platform of IIT Madras
</h2>
                <p class="lead">IIT Madras is on a journey towards global distinction in engineering and science. We aim to place IITM among the 'Top 50' global education and research institutes. We are committed to provide the best possible education and research opportunities for students and to create technology-driven social impact.

Everyone deserves access to quality education and research. Initiatives like scholarships to deserving students and funding cutting-edge research in engineering and science help enable an ‘IITM for All’. We also develop innovative technologies to solve the world's most pressing problems.

Your support can help us achieve our goals. There are many ways to support – including making a gift in honor of a loved one. So do explore the site, visit ‘Alma matters’ and share your own stories too! Please do write to us, we look forward to hearing from you!</p>
            </div>

            <!--/.row-->    
        </div><!--/.container-->
    </section>