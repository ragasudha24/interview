<section id="main-slider" class="no-margin">
        <div class="carousel slide">
            <div class="carousel-inner">

                <div class="item active" style="background-image: url(https://joyofgiving.alumni.iitm.ac.in/theme/jog/images/all-projects.png)">
                    <div class="container">
                        <div class="row slide-margin">
                            <div class="col-sm-6">
                                <div class="carousel-content">
                                    <h1 class="animation animated-item-1">Projects</h1>
                                    <h2 class="animation animated-item-2"></h2>
                                 <!--   <a class="btn-slide animation animated-item-3" href="#">Read More</a>-->
                                </div>
                            </div>

                          <!---  <div class="col-sm-6 hidden-xs animation animated-item-4">
                                <div class="slider-img">
                                    <img src="images/slider/img1.png" class="img-responsive">
                                </div>
                            </div>---->

                        </div>
                    </div>
                </div><!--/.item-->

               
                <!--/.item-->
            </div><!--/.carousel-inner-->
        </div><!--/.carousel-->
    </section>
<section>

    <div class="container">
        <div class="row">
            <div class="col-lg-3">
                <div class="filterbox">
                    <img src="https://joyofgiving.alumni.iitm.ac.in/theme/jog/images/categories-icon.svg" alt="categories-icon">
                    <h4>Categories <span class="filtercollapse"></span></h4>
                    <ul class="filterbox__list">
                                                <li class="filterbox__item  active "><span><a href="/projects/all">All Projects</a></span></li>
                                                                                                                        <li class="filterbox__item ">
                            <span><a class="" href="https://joyofgiving.alumni.iitm.ac.in/projects/cfi-student-projects">CFI Student Projects</a></span>
                        </li>
                                                                                                <li class="filterbox__item filterbox__item--haschild ">
                            <span>Infrastructure</span>
                            <ul class="filterbox__submenu">
                                                                <li class=""><a class="" href="https://joyofgiving.alumni.iitm.ac.in/projects/hostels">Hostels</a>
                                </li>
                                                                <li class=""><a class="" href="https://joyofgiving.alumni.iitm.ac.in/projects/sports">Sports Facilities</a>
                                </li>
                                                                <li class=""><a class="" href="https://joyofgiving.alumni.iitm.ac.in/projects/department">Department</a>
                                </li>
                                                                <li class=""><a class="" href="https://joyofgiving.alumni.iitm.ac.in/projects/across-institute">Across Institute</a>
                                </li>
                                                                <li class=""><a class="" href="https://joyofgiving.alumni.iitm.ac.in/projects/heritage-center">Heritage Center</a>
                                </li>
                                                            </ul>
                        </li>
                                                                                                <li class="filterbox__item ">
                            <span><a class="" href="https://joyofgiving.alumni.iitm.ac.in/projects/events">Events</a></span>
                        </li>
                                                                                                <li class="filterbox__item ">
                            <span><a class="" href="https://joyofgiving.alumni.iitm.ac.in/projects/research-development">Research &amp; Development</a></span>
                        </li>
                                                                                                <li class="filterbox__item ">
                            <span><a class="" href="https://joyofgiving.alumni.iitm.ac.in/projects/general-fund">General Fund</a></span>
                        </li>
                                                                                                <li class="filterbox__item filterbox__item--haschild ">
                            <span>Others</span>
                            <ul class="filterbox__submenu">
                                                                <li class=""><a class="" href="https://joyofgiving.alumni.iitm.ac.in/projects/uncategorised">UNCATEGORISED</a>
                                </li>
                                                            </ul>
                        </li>
                                                                                                <li class="filterbox__item ">
                            <span><a class="" href="https://joyofgiving.alumni.iitm.ac.in/projects/batch-reunion-project">Batch Reunion Project</a></span>
                        </li>
                                                                                                <li class="filterbox__item ">
                            <span><a class="" href="https://joyofgiving.alumni.iitm.ac.in/projects/students-project">Students Project</a></span>
                        </li>
                                                                        
                    </ul>
                </div>
            </div>
            <div class="col-lg-9">
            <div id="ls_values_list" class="row project__listing">


<div class="col-lg-4 col-sm-12 col-md-6">
<div class="card cardhover greencard">
<a href="/projects/general-fund/outdoor-wall-mounted-led-tv-at-himalaya-mess">
<div class="card__img">
    <img class="bgimg" src="https://joyofgiving.alumni.iitm.ac.in/data/gjafprojects/1716894812_d9391078d1088d3abe6746f136d33eafc054b8a3.jpg" alt="Outdoor Wall Mounted LED TV at Himalaya Mess" onerror="this.onerror=null;this.src='https://joyofgiving.alumni.iitm.ac.in/theme/jog/images/no_image.png';">
</div>
</a><div class="card__content"><a href="/projects/general-fund/outdoor-wall-mounted-led-tv-at-himalaya-mess">
<h3>Outdoor Wall Mounted LED TV at Himalaya Mess</h3>
                            <div class="range-slider">
<div class="progressbar__label">
<div class="progressbar__label--label">4</div>
<div class="progressbar__label--amt">
    <span>6L</span>
</div>
</div>
<input type="range" class="loan_amt range-slider__range range-slider__greenrange" max="600000" min="0" step="1" value="4" style="background: linear-gradient(90deg, #548848 0%, #cecdcd63 0%);">
</div>
    </a><a class="btn btn--white greenlabel popup__donation jg_donate_now" href="#donationpopup" title="Donate Now" tabindex="0" data-ci-url="/contribute/outdoor-wall-mounted-led-tv-at-himalaya-mess/?from=India" data-co-url="/contribute/outdoor-wall-mounted-led-tv-at-himalaya-mess/?from=others" data-cc-url="/contribute/outdoor-wall-mounted-led-tv-at-himalaya-mess/?from=Canada">Donate Now</a>
</div>
<div class="card__viewmore"><a href="/projects/general-fund/outdoor-wall-mounted-led-tv-at-himalaya-mess" class="viewmore">View
details</a></div>

</div>
</div>
<div class="col-lg-4 col-sm-12 col-md-6">
<div class="card cardhover bluecard">
<a href="/projects/events/iit-madras-sharks-aquatics-team-fund">
<div class="card__img">
    <img class="bgimg" src="https://joyofgiving.alumni.iitm.ac.in/data/gjafprojects/1720514447_aquatics.png" alt="IIT Madras Sharks Aquatics Team Fund" onerror="this.onerror=null;this.src='https://joyofgiving.alumni.iitm.ac.in/theme/jog/images/no_image.png';">
</div>
</a><div class="card__content"><a href="/projects/events/iit-madras-sharks-aquatics-team-fund">
<h3>IIT Madras Sharks Aquatics Team Fund</h3>
                            <div class="range-slider">
<div class="progressbar__label">
<div class="progressbar__label--label">54K</div>
<div class="progressbar__label--amt">
    <span>2.2L</span>
</div>
</div>
<input type="range" class="loan_amt range-slider__range range-slider__bluerange" max="220000" min="0" step="1" value="54000" style="background: linear-gradient(90deg, #475D8E 24.55%, #cecdcd63 24.55%);">
</div>
    </a><a class="btn btn--white bluelabel popup__donation jg_donate_now" href="#donationpopup" title="Donate Now" tabindex="0" data-ci-url="/contribute/iit-madras-sharks-aquatics-team-fund/?from=India" data-co-url="/contribute/iit-madras-sharks-aquatics-team-fund/?from=others" data-cc-url="/contribute/iit-madras-sharks-aquatics-team-fund/?from=Canada">Donate Now</a>
</div>
<div class="card__viewmore"><a href="/projects/events/iit-madras-sharks-aquatics-team-fund" class="viewmore">View
details</a></div>

</div>
</div>
<div class="col-lg-4 col-sm-12 col-md-6">
<div class="card cardhover pinkcard">
<a href="/projects/cfi-student-projects/global-hyperloop-competition">
<div class="card__img">
    <img class="bgimg" src="https://joyofgiving.alumni.iitm.ac.in/data/gjafprojects/1717486085_1.png" alt="Global Hyperloop Competition" onerror="this.onerror=null;this.src='https://joyofgiving.alumni.iitm.ac.in/theme/jog/images/no_image.png';">
</div>
</a><div class="card__content"><a href="/projects/cfi-student-projects/global-hyperloop-competition">
<h3>Global Hyperloop Competition</h3>
                            <div class="range-slider">
<div class="progressbar__label">
<div class="progressbar__label--label">0</div>
<div class="progressbar__label--amt">
    <span>1.5Cr</span>
</div>
</div>
<input type="range" class="loan_amt range-slider__range range-slider__pinkrange" max="15000000" min="0" step="1" value="0" style="background: linear-gradient(90deg, #AB4E8A 0%, #cecdcd63 0%);">
</div>
    </a><a class="btn btn--white greenpink popup__donation jg_donate_now" href="#donationpopup" title="Donate Now" tabindex="0" data-ci-url="/contribute/global-hyperloop-competition/?from=India" data-co-url="/contribute/global-hyperloop-competition/?from=others" data-cc-url="/contribute/global-hyperloop-competition/?from=Canada">Donate Now</a>
</div>
<div class="card__viewmore"><a href="/projects/cfi-student-projects/global-hyperloop-competition" class="viewmore">View
details</a></div>

</div>
</div>
<div class="col-lg-4 col-sm-12 col-md-6">
<div class="card cardhover dbluecard">
<a href="/projects/batch-reunion-project/1964-65-batch-class-gift-common-room-for-krishna-hostel">
<div class="card__img">
    <img class="bgimg" src="https://joyofgiving.alumni.iitm.ac.in/data/gjafprojects/1718098496_1691749499_krishna.jpg" alt="1964 - 65 Diamond Reunion Fund - Krishna Hostel Common Room" onerror="this.onerror=null;this.src='https://joyofgiving.alumni.iitm.ac.in/theme/jog/images/no_image.png';">
</div>
</a><div class="card__content"><a href="/projects/batch-reunion-project/1964-65-batch-class-gift-common-room-for-krishna-hostel">
<h3>1964 - 65 Diamond Reunion Fund - Krishna Hostel Common Room</h3>
                            <div class="range-slider">
<div class="progressbar__label">
<div class="progressbar__label--label">0</div>
<div class="progressbar__label--amt">
    <span>30L</span>
</div>
</div>
<input type="range" class="loan_amt range-slider__range range-slider__dbluerange" max="3000000" min="0" step="1" value="0" style="background: linear-gradient(90deg, #359090 0%, #cecdcd63 0%);">
</div>
    </a><a class="btn btn--white darkbluelabel popup__donation jg_donate_now" href="#donationpopup" title="Donate Now" tabindex="0" data-ci-url="/contribute/1964-65-batch-class-gift-common-room-for-krishna-hostel/?from=India" data-co-url="/contribute/1964-65-batch-class-gift-common-room-for-krishna-hostel/?from=others" data-cc-url="/contribute/1964-65-batch-class-gift-common-room-for-krishna-hostel/?from=Canada">Donate Now</a>
</div>
<div class="card__viewmore"><a href="/projects/batch-reunion-project/1964-65-batch-class-gift-common-room-for-krishna-hostel" class="viewmore">View
details</a></div>

</div>
</div>
<div class="col-lg-4 col-sm-12 col-md-6">
<div class="card cardhover greencard">
<a href="/projects/batch-reunion-project/1964-65-batch-class-gift-common-room-for-cauvery-hostel">
<div class="card__img">
    <img class="bgimg" src="https://joyofgiving.alumni.iitm.ac.in/data/gjafprojects/1718097514_1704798658_1702016747_cau2.jpg" alt="1964 - 65 Diamond Reunion Fund - Cauvery Hostel Common Room" onerror="this.onerror=null;this.src='https://joyofgiving.alumni.iitm.ac.in/theme/jog/images/no_image.png';">
</div>
</a><div class="card__content"><a href="/projects/batch-reunion-project/1964-65-batch-class-gift-common-room-for-cauvery-hostel">
<h3>1964 - 65 Diamond Reunion Fund - Cauvery Hostel Common Room</h3>
                            <div class="range-slider">
<div class="progressbar__label">
<div class="progressbar__label--label">0</div>
<div class="progressbar__label--amt">
    <span>30L</span>
</div>
</div>
<input type="range" class="loan_amt range-slider__range range-slider__greenrange" max="3000000" min="0" step="1" value="0" style="background: linear-gradient(90deg, #548848 0%, #cecdcd63 0%);">
</div>
    </a><a class="btn btn--white greenlabel popup__donation jg_donate_now" href="#donationpopup" title="Donate Now" tabindex="0" data-ci-url="/contribute/1964-65-batch-class-gift-common-room-for-cauvery-hostel/?from=India" data-co-url="/contribute/1964-65-batch-class-gift-common-room-for-cauvery-hostel/?from=others" data-cc-url="/contribute/1964-65-batch-class-gift-common-room-for-cauvery-hostel/?from=Canada">Donate Now</a>
</div>
<div class="card__viewmore"><a href="/projects/batch-reunion-project/1964-65-batch-class-gift-common-room-for-cauvery-hostel" class="viewmore">View
details</a></div>

</div>
</div>
<div class="col-lg-4 col-sm-12 col-md-6">
<div class="card cardhover bluecard">
<a href="/projects/department/doms-indian-corporate-case-study-development-centre">
<div class="card__img">
    <img class="bgimg" src="https://joyofgiving.alumni.iitm.ac.in/data/gjafprojects/1705827464_images_23.jpg" alt="DoMS Indian Corporate Case Study Development Centre" onerror="this.onerror=null;this.src='https://joyofgiving.alumni.iitm.ac.in/theme/jog/images/no_image.png';">
</div>
</a><div class="card__content"><a href="/projects/department/doms-indian-corporate-case-study-development-centre">
<h3>DoMS Indian Corporate Case Study Development Centre</h3>
                            <div class="range-slider">
<div class="progressbar__label">
<div class="progressbar__label--label">1K</div>
<div class="progressbar__label--amt">
    <span>2Cr</span>
</div>
</div>
<input type="range" class="loan_amt range-slider__range range-slider__bluerange" max="20000000" min="0" step="1" value="1000" style="background: linear-gradient(90deg, #475D8E 0.01%, #cecdcd63 0.01%);">
</div>
    </a><a class="btn btn--white bluelabel popup__donation jg_donate_now" href="#donationpopup" title="Donate Now" tabindex="0" data-ci-url="/contribute/doms-indian-corporate-case-study-development-centre/?from=India" data-co-url="/contribute/doms-indian-corporate-case-study-development-centre/?from=others" data-cc-url="/contribute/doms-indian-corporate-case-study-development-centre/?from=Canada">Donate Now</a>
</div>
<div class="card__viewmore"><a href="/projects/department/doms-indian-corporate-case-study-development-centre" class="viewmore">View
details</a></div>

</div>
</div>
<div class="col-lg-4 col-sm-12 col-md-6">
<div class="card cardhover pinkcard">
<a href="/projects/general-fund/amalgam-2024-annual-materials-engineering-fest-1">
<div class="card__img">
    <img class="bgimg" src="https://joyofgiving.alumni.iitm.ac.in/data/gjafprojects/1706182186_screenshot_2024_01_25_at_16_57_17_donate_page_for_for_amalgam_metsa_annual_materials_engineering_fest_jog_adminatalumniiitmacin_indian_institute_of_technology_madras_mail.png" alt="Amalgam 2024 - Annual Materials Engineering Fest" onerror="this.onerror=null;this.src='https://joyofgiving.alumni.iitm.ac.in/theme/jog/images/no_image.png';">
</div>
</a><div class="card__content"><a href="/projects/general-fund/amalgam-2024-annual-materials-engineering-fest-1">
<h3>Amalgam 2024 - Annual Materials Engineering Fest</h3>
                            <div class="range-slider">
<div class="progressbar__label">
<div class="progressbar__label--label">6K</div>
<div class="progressbar__label--amt">
    <span>15L</span>
</div>
</div>
<input type="range" class="loan_amt range-slider__range range-slider__pinkrange" max="1500000" min="0" step="1" value="6000" style="background: linear-gradient(90deg, #AB4E8A 0.4%, #cecdcd63 0.4%);">
</div>
    </a><a class="btn btn--white greenpink popup__donation jg_donate_now" href="#donationpopup" title="Donate Now" tabindex="0" data-ci-url="/contribute/amalgam-2024-annual-materials-engineering-fest-1/?from=India" data-co-url="/contribute/amalgam-2024-annual-materials-engineering-fest-1/?from=others" data-cc-url="/contribute/amalgam-2024-annual-materials-engineering-fest-1/?from=Canada">Donate Now</a>
</div>
<div class="card__viewmore"><a href="/projects/general-fund/amalgam-2024-annual-materials-engineering-fest-1" class="viewmore">View
details</a></div>

</div>
</div>
<div class="col-lg-4 col-sm-12 col-md-6">
<div class="card cardhover dbluecard">
<a href="/projects/batch-reunion-project/1974-batch-golden-reunion">
<div class="card__img">
    <img class="bgimg" src="https://joyofgiving.alumni.iitm.ac.in/data/gjafprojects/1714713529_1691737183_alasdfankananda.jpg" alt="1974 Batch Golden Reunion" onerror="this.onerror=null;this.src='https://joyofgiving.alumni.iitm.ac.in/theme/jog/images/no_image.png';">
</div>
</a><div class="card__content"><a href="/projects/batch-reunion-project/1974-batch-golden-reunion">
<h3>1974 Batch Golden Reunion</h3>
                            <div class="range-slider">
<div class="progressbar__label">
<div class="progressbar__label--label">0</div>
<div class="progressbar__label--amt">
    <span>50L</span>
</div>
</div>
<input type="range" class="loan_amt range-slider__range range-slider__dbluerange" max="5000000" min="0" step="1" value="0" style="background: linear-gradient(90deg, #359090 0%, #cecdcd63 0%);">
</div>
    </a><a class="btn btn--white darkbluelabel popup__donation jg_donate_now" href="#donationpopup" title="Donate Now" tabindex="0" data-ci-url="/contribute/1974-batch-golden-reunion/?from=India" data-co-url="/contribute/1974-batch-golden-reunion/?from=others" data-cc-url="/contribute/1974-batch-golden-reunion/?from=Canada">Donate Now</a>
</div>
<div class="card__viewmore"><a href="/projects/batch-reunion-project/1974-batch-golden-reunion" class="viewmore">View
details</a></div>

</div>
</div>
<div class="col-lg-4 col-sm-12 col-md-6">
<div class="card cardhover greencard">
<a href="/projects/general-fund/student-mess-fund">
<div class="card__img">
    <img class="bgimg" src="https://joyofgiving.alumni.iitm.ac.in/data/gjafprojects/1708681863_dijwosiuwae5jig.jpg" alt="Student Mess Fund" onerror="this.onerror=null;this.src='https://joyofgiving.alumni.iitm.ac.in/theme/jog/images/no_image.png';">
</div>
</a><div class="card__content"><a href="/projects/general-fund/student-mess-fund">
<h3>Student Mess Fund</h3>
                            <div class="range-slider">
<div class="progressbar__label">
<div class="progressbar__label--label">26.82L</div>
<div class="progressbar__label--amt">
    <span>99L</span>
</div>
</div>
<input type="range" class="loan_amt range-slider__range range-slider__greenrange" max="9900000" min="0" step="1" value="2682244" style="background: linear-gradient(90deg, #548848 27.09%, #cecdcd63 27.09%);">
</div>
    </a><a class="btn btn--white greenlabel popup__donation jg_donate_now" href="#donationpopup" title="Donate Now" tabindex="0" data-ci-url="/contribute/student-mess-fund/?from=India" data-co-url="/contribute/student-mess-fund/?from=others" data-cc-url="/contribute/student-mess-fund/?from=Canada">Donate Now</a>
</div>
<div class="card__viewmore"><a href="/projects/general-fund/student-mess-fund" class="viewmore">View
details</a></div>

</div>
</div>

<ul style="display:none" id="hid" relid="" calval="all">
</ul>
<input type="hidden" id="currpage" value="1">
<input type="hidden" id="currpagecontent">
<input type="hidden" id="total_projects" value="119">
</div>
        </div> 

    </div><!---row-->

</div><!--container--->
</section>