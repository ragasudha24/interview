<!DOCTYPE html>
<html lang="en">
<head>
   @include('home.head')
</head><!--/head-->

<body class="homepage">

    <header id="header">
        @include('home.header')
            </header>
        <!--/header-->

        <!--/#main-slider-->

        @include('home.projects')

        <!--/#conatcat-info-->
        @include('home.bottom')

        <!--/#bottom-->
        @include('home.footer')

        <!--/#footer-->
    </body>
</html>