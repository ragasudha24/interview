<!DOCTYPE html>
<html lang="en">
<head>
   @include('home.head')
</head><!--/head-->

<body class="homepage">

    <header id="header">
    @include('home.header')
            </header>
    <!--/header-->

    <!--/#main-slider-->
    @include('home.main-slider')

    @include('home.feature')

   <!--/#feature-->
   @include('home.recent-work')

    <!--/#recent-works-->

   <!--/#services-->
@include('home.pricing')

<!--/#middle-->

    <!--/#content-->
    @include('home.team')
    @include('home.alpha')

    <!--/#partner-->

    <!--/#conatcat-info-->
    @include('home.bottom')

    <!--/#bottom-->
    @include('home.footer')

    <!--/#footer-->
    </body>
</html>