<section>
<div class="container">    <div class="center"><h2>Alma Matters</h2></div>

    <div class="row" style="background:#f8f8f8;">
    <div class="col-sm-6">	
    <img style="width:100%;"src="https://joyofgiving.alumni.iitm.ac.in/data/images/cache/blogs/92cc0121d2acce75bff5eab8bba36383054d30d1.png" alt="IIT Madras Alumni Revisit Their Roots and Celebrate New Beginnings" title="IIT Madras Alumni Revisit Their Roots and Celebrate New Beginnings">
</div>
<div class="col-sm-6" >	
<h3>19 July 2024</h3>
                <h4>IIT Madras Alumni Revisit Their Roots and Celebrate New Beginnings</h4>
                <p>It was a day filled with nostalgic reflections. It shared triumphs as esteemed alumni of IIT Madras, Dr. Shivashankar T.S., VP of Operations at INDO MIM Pvt Ltd, and Mr. Sridhara Ramachandran, VP of Aerospace Solutions Group at INDO MIM Pvt Ltd, returned to their alma mater.</p><a href="https://joyofgiving.alumni.iitm.ac.in/alma-matters/insti-buzz/iit-madras-alumni-revisit-their-roots-and-celebrate-new-beginnings" class="link">Continue Reading</a>

</div>
</div>
</div>
</section>