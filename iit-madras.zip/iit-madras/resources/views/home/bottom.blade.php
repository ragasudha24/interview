    <div class="subscribe__form get-started center wow fadeInDown animated" style="visibility: visible; animation-name: fadeInDown;background: none repeat scroll 0 0 #9d902b;padding-top:0px;">
                <h2>Sign up for Newsletter
</h2>
                <p class="lead"><input type="text" class="text-field" id="email" name="email" placeholder="Enter your email address"> </p>
                <div class="request">
                    <h4><a href="#">Subscribe for free Now</a></h4>
                </div>
            </div>

<section id="bottom">
        <div class=" container wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="600ms">
            <div class="row">
                <div class="col-sm-4">
                <div class="logo"><a href="https://joyofgiving.alumni.iitm.ac.in"><img src="https://joyofgiving.alumni.iitm.ac.in/theme/jog/images/logo.svg" alt="Joy of giving" title="Joy Of Giving" class="logo"></a></div>
                    <p class="content">Joy of Giving to IITM is a fundraising platform intended to aid IIT Madras' journey
                        towards global distinction in the fields of engineering education and research.</p>


</div>
<div class="col-sm-4">
<h3>Visit</h3>
                    <div class="category">
                                                <ul>
                                                                                                                <li>
                                                            <a title="IIT Madras" href="http://www.iitm.ac.in/" target="_blank">IIT Madras</a>
                            
                            </li>
                                                                                                                <li>
                                                            <a title="Canadian Friends of IITM" href="https://acr.iitm.ac.in/cfiitm/" target="_blank">Canadian Friends of IITM</a>
                            
                            </li>
                                                                                                                <li>
                                                            <a title="IITM Foundation" href="https://iitmfoundation.org/" target="_blank">IITM Foundation</a>
                            
                            </li>
                                                                                                                <li>
                                                            <a title="SocIITy" href="https://sociity.in" target="_blank">SocIITy</a>
                            
                            </li>
                                                                                </ul>
                                            </div>
</div>
<div class="col-sm-4">
    

<h3>Useful links</h3>
                    <div class="category">
                        <ul>
                                                                                                                                            <li>
                                                            <a title="The Team" href="/the-team">The Team</a>
                                                        </li>
                                                                                                                <li>
                                                            <a title="Chair-Professorship-Brochure" href="https://acr.iitm.ac.in/wp-content/uploads/2022/12/updated.2-01.pdf" target="_blank">Chair-Professorship-Brochure</a>
                                                        </li>
                                                                                                                <li>
                                                            <a title="Annual Giving Reports" href="/agr">Annual Giving Reports</a>
                                                        </li>
                                                                                                                <li>
                                                            <a title="IT Documents" href="/itdocs">IT Documents</a>
                                                        </li>
                                                                                                                <li>
                                                            <a title="Wire Transfer Details" href="https://joyofgiving.alumni.iitm.ac.in/form/wiretransfer/" target="_blank">Wire Transfer Details</a>
                                                        </li>
                                                                                                            </ul>
                    </div>

</div>
            </div>
        </div>
    </section>