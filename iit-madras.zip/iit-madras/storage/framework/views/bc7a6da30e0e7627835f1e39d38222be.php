<section id="recent-works">
        <div class="container">
            <div class="center wow fadeInDown">
                <h2>IITM Alums Upgrade The Campus</h2>
                <p class="lead"></p>
            </div>

            <div class="row">
                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="https://joyofgiving.alumni.iitm.ac.in/data/cms/Manohar_C_Watsa_Stadium_328_x_376_02.jpg" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="#">Manohar C Watsa Stadium</a> </h3>
                                <p>"The Institute's glorious stadium thanks to Shri Prem Watsa, Distingushed Alumnus of IIT Madras and Chairman of Fairfax Financial Holdings, which has been named in honour of his father, the late Manohar C. Watsa. The 400-meter, eight-lane synthetic track also has platforms for the long jump, triple jump, and pole vault."</p>
                                <a class="preview" href="images/portfolio/full/item1.png" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                            </div> 
                        </div>
                    </div>
                </div>   

                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="https://joyofgiving.alumni.iitm.ac.in/data/cms/Centre_For_Innovation_328_x_376.jpg" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="#">Centre For Innovation</a></h3>
                                <p>The Centre for Innovation (CFI) was established in 2008 with seed funding by the class of 1981. The 24x7 Student Lab has now moved to the recently constructed, state-of-the-art Sudha and Shankar Innovation Hub, thanks to our munificent patron, Shri. V. Shankar, Distinguished Alumnus of IIT Madras, founder of CAMS Pvt Ltd.</p>
                                <a class="preview" href="images/portfolio/full/item2.png" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                            </div> 
                        </div>
                    </div>
                </div> 

                <div class="col-xs-12 col-sm-4 col-md-4">
                    <div class="recent-work-wrap">
                        <img class="img-responsive" src="https://joyofgiving.alumni.iitm.ac.in/data/cms/Department_of_Computer_Science_and_Engineering_328_x_376_01.jpg" alt="">
                        <div class="overlay">
                            <div class="recent-work-inner">
                                <h3><a href="#">Department of Computer Science and Engineering </a></h3>
                                <p>The generous gift of IIT Madras' Distinguished Alumnus, Mr. Subramonian Shankar, Founder and President, AmZetta Technologies, stands tall: a new three-storey extension to the Department of Computer Science and Engineering</p>
                                <a class="preview" href="images/portfolio/full/item3.png" rel="prettyPhoto"><i class="fa fa-eye"></i> View</a>
                            </div> 
                        </div>
                    </div>
                </div>   

                
                
                  
            </div><!--/.row-->
        </div><!--/.container-->
    </section><?php /**PATH /data/laravel/iit-madras/resources/views/home/recent-work.blade.php ENDPATH**/ ?>