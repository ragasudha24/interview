<!DOCTYPE html>
<html lang="en">
<head>
   <?php echo $__env->make('home.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head><!--/head-->

<body class="homepage">

    <header id="header">
        <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </header>
        <!--/header-->

        <!--/#main-slider-->

        <?php echo $__env->make('home.projects', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--/#conatcat-info-->
        <?php echo $__env->make('home.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--/#bottom-->
        <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <!--/#footer-->
    </body>
</html><?php /**PATH /data/laravel/iit-madras/resources/views/home/project.blade.php ENDPATH**/ ?>