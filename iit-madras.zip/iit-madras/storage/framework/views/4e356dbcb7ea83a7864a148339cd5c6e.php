<!-- our-team -->
<div class="container">
<div class="team">
				<div class="center wow fadeInDown">
					<h2>MessagesFrom Our Team Members</h2>
				</div>

				<div class="row clearfix">
					<div class="col-md-4 col-sm-6">	
						<div class="single-profile-top wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="media">
								<div class="pull-left">
									<a href="#"><img class="media-object" style="width:150px;" src="https://joyofgiving.alumni.iitm.ac.in/data/cms/Dean_687x366.jpg" alt=""></a>
								</div>
								<div class="media-body">
                                <h4>Prof. Mahesh Panchagnula</h4>
									<h5>Department of Applied Mechanics,Dean, Alumni & Corporate Relations,IIT Madras.

</h5>								
									
								</div>
							</div><!--/.media -->
							<p>As an institution, we have grown in the last 64 years, from being a fledgling, primarily undergraduate teaching institution being nurtured by German faculty members, to today, becoming India’s #1 ranked institution across various prestigious national rankings like the NIRF and the AIIRA, housing 10,000+ students 600+ faculty, with active involvement in world-class research.
</p><a class="btn readmore" href="blog-item.html">Read More <i class="fa fa-angle-right"></i></a>
						</div>
					</div><!--/.col-lg-4 -->
					
					
					<div class="col-md-4 col-sm-6 col-md-offset-2">	
						<div class="single-profile-top wow fadeInDown" data-wow-duration="1000ms" data-wow-delay="300ms">
							<div class="media">
								<div class="pull-left">
									<a href="#"><img class="media-object" style="width:150px;" src="https://joyofgiving.alumni.iitm.ac.in/data/cms/kaviraj-nair-ceo.png" alt=""></a>
								</div>
								<div class="media-body">
									<h4>Mr. Kaviraj Nair
</h4>
									<h5>CEO, Office of Institutional Advancement,
IIT Madras.

</h5>
									
								</div>
							</div><!--/.media -->
							<p>The institute has been able to establish itself as India’s continuing leader in academic excellence, innovation and technological expertise, thanks to the growing support of our committed alumni and generous patrons, year after year. We are very proud of our large and vibrant alumni community, the extended family of IIT Madras.
</p>
                            <a class="btn readmore" href="blog-item.html">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
					</div><!--/.col-lg-4 -->					
				</div> <!--/.row -->
				<div class="row team-bar">
					<div class="first-one-arrow hidden-xs">
						<hr>
					</div>
					<div class="first-arrow hidden-xs">
						<hr> <i class="fa fa-angle-up"></i>
					</div>
					<div class="second-arrow hidden-xs">
						<hr> <i class="fa fa-angle-down"></i>
					</div>
					<div class="third-arrow hidden-xs">
						<hr> <i class="fa fa-angle-up"></i>
					</div>
					<div class="fourth-arrow hidden-xs">
						<hr> <i class="fa fa-angle-down"></i>
					</div>
				</div> <!--skill_border-->       

				<div class="row clearfix">   
					<div class="col-md-4 col-sm-6 col-md-offset-2">	
						<div class="single-profile-bottom wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="600ms">
							<div class="media">
								<div class="pull-left">
									<a href="#"><img class="media-object" style="width:150px;" src="https://joyofgiving.alumni.iitm.ac.in/data/images/cache/testimonial/2c4b9b4354726cfd60c900465738fa97dbf8f458.png" alt=""></a>
								</div>

								<div class="media-body">
									<h4>— Shri T. T. Jagannathan
</h4>
									<h5>Managing Director, TTK Group of Companies | Alumnus of IIT Madras

</h5>
									
								</div>
							</div><!--/.media -->
							<p>The only hope for eliminating poverty in India is through technology. It has to be that kind of technology that benefits the people on the ground. I am happy to say that the research already funded by us through R2D2 is bringing real benefits to people with disabilities I wish to congratulate IITM for this initiative.
</p>                            

						</div>
					</div>
					<div class="col-md-4 col-sm-6 col-md-offset-2">
						<div class="single-profile-bottom wow fadeInUp" data-wow-duration="1000ms" data-wow-delay="600ms">
							<div class="media">
								<div class="pull-left">
									<a href="#"><img class="media-object" style="width:150px;" src="https://joyofgiving.alumni.iitm.ac.in/data/cms/Kris_Gopalakrishnan_325x351.jpg" alt=""></a>
								</div>
								<div class="media-body">
									<h4>Shri S. Gopalakrishnan
</h4>
									<h5>Chairman Axilor Ventures
Co-founder Infosys
1977/M.Sc/PHY & 1979/MT/CS

</h5>
									
								</div>
							</div><!--/.media -->
							<p>Shri S Gopalakrishnan represents a generation of engineer-scientists who have made India a global player in software industry. After this formative experience, Shri Gopalakrishnan had a fair idea of the shape of things to come….</p>
                            <a class="btn readmore" href="blog-item.html">Read More <i class="fa fa-angle-right"></i></a>
                        </div>
					</div>
				</div>	<!--/.row-->
			</div>
</div><?php /**PATH /data/laravel/iit-madras/resources/views/home/team.blade.php ENDPATH**/ ?>