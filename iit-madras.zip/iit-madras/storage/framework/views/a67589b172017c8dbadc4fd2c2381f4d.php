<section class="pricing-page">
    <div class="container">
        <div class="center">  
            <h2>What's New</h2>
            <p class="lead"></p>
        </div>  
        <div class="pricing-area text-center">
            <div class="row">
                <div class="col-sm-4 plan ">
                    <img src="https://joyofgiving.alumni.iitm.ac.in/data/images/cache/sm_post/4349f9486e956e846291696a75379c4dd9be9f5c.png">
                   
                </div>

                <div class="col-sm-4 plan ">
                <img src="https://joyofgiving.alumni.iitm.ac.in/data/images/cache/sm_post/2e8010aaf58c1e4924ae377b17fb36a483646e43.jpg">
                                    </div>

                <div class="col-sm-4 plan ">
                <img src="https://joyofgiving.alumni.iitm.ac.in/data/images/cache/sm_post/7e58eb7022daac0ba005958ee9ff27478537508a.jpg">

                                   </div>

               
               
            </div>
        

        </div><!--/pricing-area-->
    </div><!--/container-->
</section><?php /**PATH /data/laravel/iit-madras/resources/views/home/pricing.blade.php ENDPATH**/ ?>