<section id="main-slider" class="no-margin">
        <div class="carousel slide">
            <ol class="carousel-indicators">
                <li data-target="#main-slider" data-slide-to="0" class="active"></li>
                <li data-target="#main-slider" data-slide-to="1"></li>
                <li data-target="#main-slider" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">

                <div class="item active" style="background-image: url(https://joyofgiving.alumni.iitm.ac.in/data/images/cache/banner/b7e5ea30a83f0d2ef920378795f719c1ae84645c.jpg)">
                    <div class="container">
                        <div class="row slide-margin">
                            <div class="col-sm-6">
                                <div class="carousel-content">
                                    <h1 class="animation animated-item-1">IITM Alumni Giving</h1>
                                    <h2 class="animation animated-item-2">helps insti grow by leaps and bounds</h2>
                                 <!--   <a class="btn-slide animation animated-item-3" href="#">Read More</a>-->
                                </div>
                            </div>

                          <!---  <div class="col-sm-6 hidden-xs animation animated-item-4">
                                <div class="slider-img">
                                    <img src="images/slider/img1.png" class="img-responsive">
                                </div>
                            </div>---->

                        </div>
                    </div>
                </div><!--/.item-->

                <div class="item" style="background-image: url(https://joyofgiving.alumni.iitm.ac.in/data/images/cache/banner/19cb45dfb9d2e9b035ff6d1bbe3373757161679e.jpg)">
                    <div class="container">
                        <div class="row slide-margin">
                            <div class="col-sm-6">
                                <div class="carousel-content">
                                    <h1 class="animation animated-item-1">Let us together grow IIT Madras</h1>
                                    <h2 class="animation animated-item-2">Prof Mahesh Panchagnula, Dean, Alumni and Corporate Relations, IIT Madras.</h2>
                                </div>
                            </div>


                        </div>
                    </div>
                </div><!--/.item-->

                <div class="item" style="background-image: url(https://joyofgiving.alumni.iitm.ac.in/data/images/cache/banner/0c772240019ca365cc731dca6198a802f1febfc0.png)">
                    <div class="container">
                        <div class="row slide-margin">
                            <div class="col-sm-6">
                                <div class="carousel-content">
                                    <h1 class="animation animated-item-1">From Crossroads to Breakthroughs</h1>
                                    <h2 class="animation animated-item-2">Give a boost to key Research Initiatives at IITM</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div><!--/.item-->
            </div><!--/.carousel-inner-->
        </div><!--/.carousel-->
        <a class="prev hidden-xs" href="#main-slider" data-slide="prev">
            <i class="fa fa-chevron-left"></i>
        </a>
        <a class="next hidden-xs" href="#main-slider" data-slide="next">
            <i class="fa fa-chevron-right"></i>
        </a>
    </section><?php /**PATH /data/laravel/iit-madras/resources/views/home/main-slider.blade.php ENDPATH**/ ?>