<!DOCTYPE html>
<html lang="en">
<head>
   <?php echo $__env->make('home.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head><!--/head-->

<body class="homepage">

    <header id="header">
    <?php echo $__env->make('home.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </header>
    <!--/header-->

    <!--/#main-slider-->
    <?php echo $__env->make('home.main-slider', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php echo $__env->make('home.feature', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

   <!--/#feature-->
   <?php echo $__env->make('home.recent-work', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--/#recent-works-->

   <!--/#services-->
<?php echo $__env->make('home.pricing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!--/#middle-->

    <!--/#content-->
    <?php echo $__env->make('home.team', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('home.alpha', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--/#partner-->

    <!--/#conatcat-info-->
    <?php echo $__env->make('home.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--/#bottom-->
    <?php echo $__env->make('home.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <!--/#footer-->
    </body>
</html><?php /**PATH /data/laravel/iit-madras/resources/views/home/home.blade.php ENDPATH**/ ?>