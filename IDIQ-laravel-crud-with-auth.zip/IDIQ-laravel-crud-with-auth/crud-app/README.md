1)unzip Files
2)create database laravel_crud and give details to .env file
3)Go to root folder 
 Execute Command : 
  1)composer install
  2)php artisan migrate
  3)php artisan serve

 3)check below path:
  http://localhost:8000/login
  http://localhost:8000/registration
  
  
  http://localhost:8000/category/
