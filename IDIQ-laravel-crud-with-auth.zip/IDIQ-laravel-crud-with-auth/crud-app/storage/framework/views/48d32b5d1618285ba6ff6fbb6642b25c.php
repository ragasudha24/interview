<?php $__env->startSection('content'); ?>

    <div class="container">


    <div class="d-flex bd-highlight mb-3">
  <div class="p-2 bd-highlight">    welcome    <h3><?php echo e($data->name); ?></h3>
  </div>
  <div class="ms-auto p-2 bd-highlight">
  <a href="<?php echo e(url('dashboard')); ?>" class="btn btn-success">Dashboard</a>
</div>
</div>

        <div class="row">
            <div class="col-md-12">

                <?php $__sessionArgs = ['status'];
if (session()->has($__sessionArgs[0])) :
if (isset($value)) { $__sessionPrevious[] = $value; }
$value = session()->get($__sessionArgs[0]); ?>
                <div class="alert alert-success">
                    <?php echo e(session('status')); ?>

                </div>
                <?php unset($value);
if (isset($__sessionPrevious) && !empty($__sessionPrevious)) { $value = array_pop($__sessionPrevious); }
if (isset($__sessionPrevious) && empty($__sessionPrevious)) { unset($__sessionPrevious); }
endif;
unset($__sessionArgs); ?>

                <div class="card">
                    <div class="card-header">
                        <h4>Categories List
                            <a href="<?php echo e(url('category/create')); ?>" class="btn btn-primary float-end">Add Category</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <table class="table table-stiped table-bordered">
                            <thead>
                                <tr>
                                    <th>Id</th>
                                    <th>Name</th>
                                    <th>Description</th>
                                    <th>Status</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($category->id); ?></td>
                                    <td><?php echo e($category->name); ?></td>
                                    <td><?php echo e($category->description); ?></td>
                                    <td><?php echo e($category->status == 1 ? 'Visible':'Hidden'); ?></td>
                                    <td>
                                        <a href="<?php echo e(route('category.edit', $category->id)); ?>" class="btn btn-success">Edit</a>
                                        <a href="<?php echo e(route('category.show', $category->id)); ?>" class="btn btn-info">Show</a>


                                        <form action="<?php echo e(route('category.destroy', $category->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger">Delete</button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <?php echo e($categories->links()); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('category.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/laravel/idiq/crud-app/resources/views/category/index.blade.php ENDPATH**/ ?>