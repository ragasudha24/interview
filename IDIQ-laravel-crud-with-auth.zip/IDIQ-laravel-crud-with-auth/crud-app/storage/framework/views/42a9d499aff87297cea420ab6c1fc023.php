<?php $__env->startSection('content'); ?>

    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <h4>Show Category Detail
                            <a href="<?php echo e(url('category')); ?>" class="btn btn-danger float-end">Back</a>
                        </h4>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="text-primary">Name</label>
                            <p>
                                <?php echo e($category->name); ?>

                            </p>
                        </div>
                        <div class="mb-3">
                            <label class="text-primary">Description</label>
                            <p>
                                <?php echo $category->description; ?>

                            </p>
                        </div>
                        <div class="mb-3">
                            <label class="text-primary">Status</label>
                            <br/>
                            <p>
                                <?php echo e($category->status == 1 ? 'checked':''); ?>

                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('category.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /data/laravel/idiq/crud-app/resources/views/category/show.blade.php ENDPATH**/ ?>